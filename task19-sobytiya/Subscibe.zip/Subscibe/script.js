const subsBtn = document.querySelector(".subs-button");
const bellIcon = document.querySelector(".bell-icon");
const subsText = document.querySelector(".subs-text");

let activeBtn = false;
let activeBell = false;

subsBtn.addEventListener("click", () => {
  if (activeBtn === false) {
    subsText.innerText = "Subscribed";
    subsBtn.style.backgroundColor = "grey";
    bellIcon.style.display = "inline-block";
    activeBtn = true;
  } else if (activeBtn === true) {
    subsText.innerText = "Subscribe";
    subsBtn.style.backgroundColor = "red";
    bellIcon.style.display = "none";

    //сбрасываем иконку
    bellIcon.src = "assets/bell.png";
    activeBtn = false;
    activeBell = false;
  }
});

bellIcon.addEventListener("click", (event) => {
  if (activeBell === false) {
    bellIcon.src = "assets/bell-active.png";
    activeBell = true;
  } else if (activeBell === true) {
    bellIcon.src = "assets/bell.png";
    activeBell = false;
  }

  event.stopPropagation();
});
